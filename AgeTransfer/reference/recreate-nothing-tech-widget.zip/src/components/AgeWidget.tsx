import DotMatrix from "./DotMatrix";
import { formatAge } from "../hooks/useLiveAge";

interface AgeWidgetProps {
  years: number;
  decimals: number;
  size?: "2x2" | "4x2";
  ghost?: boolean;
  hasBirth: boolean;
}

export default function AgeWidget({ years, decimals, size = "2x2", ghost, hasBirth }: AgeWidgetProps) {
  const text = hasBirth ? formatAge(years, decimals) : "--.---------";
  const wide = size === "4x2";

  return (
    <div
      className={[
        "relative flex items-center justify-center bg-[#1c1c1c] shadow-[0_20px_60px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.05)]",
        wide ? "aspect-[2/1] w-full max-w-[560px]" : "aspect-square w-full max-w-[300px]",
      ].join(" ")}
      style={{ borderRadius: wide ? "18%/36%" : "20%" }}
    >
      <div className="w-[86%]">
        <DotMatrix text={text} ghost={ghost} className="block w-full" />
      </div>
    </div>
  );
}
