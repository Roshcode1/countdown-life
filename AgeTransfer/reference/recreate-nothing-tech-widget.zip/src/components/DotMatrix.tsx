import { useMemo } from "react";

// 5x7 dot-matrix glyphs, in the style of Nothing's NDot typeface.
const GLYPHS: Record<string, string[]> = {
  "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
  "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
  "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
  "3": ["11111", "00010", "00100", "00010", "00001", "10001", "01110"],
  "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
  "5": ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
  "6": ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
  "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
  "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
  "9": ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
  ".": ["0", "0", "0", "0", "0", "0", "1"],
  ":": ["0", "1", "0", "0", "0", "1", "0"],
  "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
  " ": ["000", "000", "000", "000", "000", "000", "000"],
  A: ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
  D: ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
  E: ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
  G: ["01110", "10001", "10000", "10111", "10001", "10001", "01111"],
  H: ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
  I: ["01110", "00100", "00100", "00100", "00100", "00100", "01110"],
  M: ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
  N: ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
  O: ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
  R: ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
  S: ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
  T: ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
  Y: ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
};

const ROWS = 7;
const GAP = 1; // columns between glyphs

interface DotMatrixProps {
  text: string;
  className?: string;
  /** Color of lit dots */
  color?: string;
  /** Show faint unlit dots behind the glyphs */
  ghost?: boolean;
  /** Dot radius in grid units (1 unit = 1 cell) */
  radius?: number;
}

export default function DotMatrix({
  text,
  className,
  color = "#ffffff",
  ghost = false,
  radius = 0.42,
}: DotMatrixProps) {
  const { width, dots, ghosts } = useMemo(() => {
    const lit: { x: number; y: number }[] = [];
    const off: { x: number; y: number }[] = [];
    let cursor = 0;
    for (const ch of text.toUpperCase()) {
      const g = GLYPHS[ch] ?? GLYPHS[" "];
      const w = g[0].length;
      for (let y = 0; y < ROWS; y++) {
        for (let x = 0; x < w; x++) {
          const p = { x: cursor + x + 0.5, y: y + 0.5 };
          if (g[y][x] === "1") lit.push(p);
          else off.push(p);
        }
      }
      cursor += w + GAP;
    }
    return { width: Math.max(cursor - GAP, 1), dots: lit, ghosts: off };
  }, [text]);

  return (
    <svg
      viewBox={`0 0 ${width} ${ROWS}`}
      className={className}
      preserveAspectRatio="xMidYMid meet"
      aria-label={text}
      role="img"
    >
      {ghost &&
        ghosts.map((p, i) => (
          <circle key={`g${i}`} cx={p.x} cy={p.y} r={radius} fill={color} opacity={0.07} />
        ))}
      {dots.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={radius} fill={color} />
      ))}
    </svg>
  );
}
