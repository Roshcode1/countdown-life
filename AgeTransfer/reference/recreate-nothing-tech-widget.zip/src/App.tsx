import { useEffect, useMemo, useState } from "react";
import AgeWidget from "./components/AgeWidget";
import DotMatrix from "./components/DotMatrix";
import { useLiveAge } from "./hooks/useLiveAge";

const STORAGE_KEY = "age-in-motion:settings";

interface Settings {
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  decimals: number;
  size: "2x2" | "4x2";
  ghost: boolean;
}

const DEFAULTS: Settings = {
  date: "1997-08-15",
  time: "09:30",
  decimals: 9,
  size: "2x2",
  ghost: false,
};

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return DEFAULTS;
}

function toTimestamp(date: string, time: string): number | null {
  if (!date) return null;
  const t = new Date(`${date}T${time || "00:00"}:00`).getTime();
  return Number.isNaN(t) ? null : t;
}

const fmtInt = (n: number) => Math.floor(n).toLocaleString("en-US");

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const birth = useMemo(() => toTimestamp(settings.date, settings.time), [settings.date, settings.time]);
  const { years, elapsedMs } = useLiveAge(birth);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  const update = <K extends keyof Settings>(key: K, value: Settings[K]) =>
    setSettings((s) => ({ ...s, [key]: value }));

  const hasBirth = birth !== null;
  const days = elapsedMs / 86_400_000;
  const nextBirthdayIn = hasBirth ? (Math.ceil(years) - years) * 365.2425 : 0;
  const stats = [
    { label: "Days lived", value: fmtInt(days) },
    { label: "Hours lived", value: fmtInt(elapsedMs / 3_600_000) },
    { label: "Heartbeats (approx.)", value: fmtInt((elapsedMs / 60_000) * 72) },
    { label: "Next birthday in", value: `${fmtInt(nextBirthdayIn)} days` },
  ];

  return (
    <div className="min-h-screen bg-black font-mono text-white selection:bg-[#d71921] selection:text-white">
      {/* top bar */}
      <header className="mx-auto flex w-full max-w-3xl items-center justify-between px-6 pt-8">
        <div className="flex items-center gap-3">
          <span className="h-2.5 w-2.5 rounded-full bg-[#d71921]" />
          <span className="text-[11px] uppercase tracking-[0.3em] text-white/70">Age in Motion</span>
        </div>
        <span className="text-[11px] uppercase tracking-[0.3em] text-white/40">Widget</span>
      </header>

      <main className="mx-auto flex w-full max-w-3xl flex-col items-center px-6 pb-20">
        {/* widget stage */}
        <section className="mt-10 flex w-full flex-col items-center">
          <AgeWidget
            years={years}
            decimals={settings.decimals}
            size={settings.size}
            ghost={settings.ghost}
            hasBirth={hasBirth}
          />
          <p className="mt-6 text-center text-[11px] uppercase tracking-[0.3em] text-white/40">
            A widget that reminds you time is running out.
          </p>
        </section>

        {/* big secondary readout */}
        <section className="mt-12 w-full border-t border-white/10 pt-8">
          <div className="mb-3 flex items-center justify-between text-[11px] uppercase tracking-[0.3em] text-white/40">
            <span>Years</span>
            <span className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#d71921]" />
              Live
            </span>
          </div>
          <div className="w-full max-w-[420px]">
            <DotMatrix text={hasBirth ? years.toFixed(2) : "--.--"} className="block w-full" />
          </div>
        </section>

        {/* settings */}
        <section className="mt-12 w-full border-t border-white/10 pt-8">
          <h2 className="mb-6 text-[11px] uppercase tracking-[0.3em] text-white/40">Settings</h2>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <Field label="Birth date">
              <input
                type="date"
                value={settings.date}
                max={new Date().toISOString().slice(0, 10)}
                onChange={(e) => update("date", e.target.value)}
                className={inputCls}
              />
            </Field>
            <Field label="Birth time">
              <input
                type="time"
                value={settings.time}
                onChange={(e) => update("time", e.target.value)}
                className={inputCls}
              />
            </Field>

            <Field label={`Precision · ${settings.decimals} decimals`}>
              <input
                type="range"
                min={0}
                max={10}
                value={settings.decimals}
                onChange={(e) => update("decimals", Number(e.target.value))}
                className="range w-full"
              />
            </Field>

            <Field label="Widget size">
              <Segmented
                value={settings.size}
                onChange={(v) => update("size", v as Settings["size"])}
                options={[
                  { value: "2x2", label: "2 × 2" },
                  { value: "4x2", label: "4 × 2" },
                ]}
              />
            </Field>

            <Field label="Unlit dots">
              <Segmented
                value={settings.ghost ? "on" : "off"}
                onChange={(v) => update("ghost", v === "on")}
                options={[
                  { value: "off", label: "Hidden" },
                  { value: "on", label: "Faint" },
                ]}
              />
            </Field>
          </div>
        </section>

        {/* stats */}
        <section className="mt-12 w-full border-t border-white/10 pt-8">
          <h2 className="mb-6 text-[11px] uppercase tracking-[0.3em] text-white/40">In motion</h2>
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl bg-white/10 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="bg-black p-4">
                <div className="text-[10px] uppercase tracking-[0.25em] text-white/40">{s.label}</div>
                <div className="mt-2 text-lg tabular-nums text-white">{hasBirth ? s.value : "—"}</div>
              </div>
            ))}
          </div>
        </section>

        <footer className="mt-16 flex w-full items-center justify-between text-[10px] uppercase tracking-[0.3em] text-white/30">
          <span>Essential Apps</span>
          <span>Recreated · Age in Motion by Rahul</span>
        </footer>
      </main>
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-white/15 bg-[#111] px-4 py-3 text-sm text-white outline-none transition focus:border-[#d71921] [color-scheme:dark]";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-[10px] uppercase tracking-[0.25em] text-white/50">{label}</span>
      {children}
    </label>
  );
}

function Segmented({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="grid grid-cols-2 gap-1 rounded-xl border border-white/15 bg-[#111] p-1">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={[
              "rounded-lg px-3 py-2 text-xs uppercase tracking-[0.2em] transition",
              active ? "bg-white text-black" : "text-white/60 hover:text-white",
            ].join(" ")}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
