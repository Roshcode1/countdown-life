import { useEffect, useState } from "react";

// Mean Gregorian year in milliseconds.
export const YEAR_MS = 365.2425 * 24 * 60 * 60 * 1000;

export interface LiveAge {
  years: number;
  elapsedMs: number;
}

/** Returns the continuously-updating age (in years) for a given birth timestamp. */
export function useLiveAge(birth: number | null): LiveAge {
  const [age, setAge] = useState<LiveAge>(() => compute(birth));

  useEffect(() => {
    let raf = 0;
    const tick = () => {
      setAge(compute(birth));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [birth]);

  return age;
}

function compute(birth: number | null): LiveAge {
  if (birth === null || Number.isNaN(birth)) return { years: 0, elapsedMs: 0 };
  const elapsedMs = Math.max(0, Date.now() - birth);
  return { years: elapsedMs / YEAR_MS, elapsedMs };
}

export function formatAge(years: number, decimals = 9): string {
  return years.toFixed(decimals);
}
